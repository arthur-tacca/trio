# Uses `from x import y as y` for compatibility with `pyright --verifytypes` (#2625)

from .. import _deprecate as _deprecate
from .._core import (
    MockClock as MockClock,
    wait_all_tasks_blocked as wait_all_tasks_blocked,
)
from .._threads import (
    active_thread_count as active_thread_count,
    wait_all_threads_completed as wait_all_threads_completed,
)
from .._util import fixup_module_metadata
from ._check_streams import (
    check_half_closeable_stream as check_half_closeable_stream,
    check_one_way_stream as check_one_way_stream,
    check_two_way_stream as check_two_way_stream,
)
from ._checkpoints import (
    assert_checkpoints as assert_checkpoints,
    assert_no_checkpoints as assert_no_checkpoints,
)
from ._memory_streams import (
    MemoryReceiveStream as MemoryReceiveStream,
    MemorySendStream as MemorySendStream,
    lockstep_stream_one_way_pair as lockstep_stream_one_way_pair,
    lockstep_stream_pair as lockstep_stream_pair,
    memory_stream_one_way_pair as memory_stream_one_way_pair,
    memory_stream_pair as memory_stream_pair,
    memory_stream_pump as memory_stream_pump,
)
from ._network import open_stream_to_socket_listener as open_stream_to_socket_listener
from ._raises_group import Matcher as _Matcher, RaisesGroup as _RaisesGroup
from ._sequencer import Sequencer as Sequencer
from ._trio_test import trio_test as trio_test

################################################################


_deprecate.deprecate_attributes(
    __name__,
    {
        "RaisesGroup": _deprecate.DeprecatedAttribute(
            _RaisesGroup,
            version="0.33.0",
            issue=3326,
            instead="See https://docs.pytest.org/en/stable/reference/reference.html#pytest.RaisesGroup",
        ),
        "Matcher": _deprecate.DeprecatedAttribute(
            _Matcher,
            version="0.33.0",
            issue=3326,
            instead="See https://docs.pytest.org/en/stable/reference/reference.html#pytest.RaisesExc",
        ),
    },
)

fixup_module_metadata(__name__, globals())
del fixup_module_metadata
